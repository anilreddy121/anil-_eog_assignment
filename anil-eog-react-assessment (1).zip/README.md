## Create React App Visualization

This assessment was bespoke handcrafted for anil.

Read more about this assessment [here](https://react.eogresources.com)
